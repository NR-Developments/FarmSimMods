---@class MachineScreen : TabbedMenuWithDetails
---@field superClass fun(): TabbedMenuWithDetails
---@field settingsFrame MachineSettingsFrame
---@field landscapingSettingsFrame MachineSettingsLandscapingFrame
---@field inputSettingsFrame MachineSettingsInputFrame
---@field outputSettingsFrame MachineSettingsOutputFrame
---@field areaSettingsFrame MachineSettingsAreaFrame
---@field vehicle? Machine
---@field overlayElement BitmapElement
---@field showOverlay boolean
---@field screenBgElement BitmapElement
MachineScreen = {}

MachineScreen.CLASS_NAME = 'MachineScreen'
MachineScreen.XML_FILENAME = g_modDirectory .. 'data/gui/MachineScreen.xml'

local MachineScreen_mt = Class(MachineScreen, TabbedMenuWithDetails)

function MachineScreen.new(target, customMt)
    local self = TabbedMenuWithDetails.new(target, customMt or MachineScreen_mt)
    ---@cast self MachineScreen

    self.currentPageName = ''
    self.showOverlay = false

    return self
end

function MachineScreen:load()
    self.settingsFrame = MachineSettingsFrame.new(self)
    self.inputSettingsFrame = MachineSettingsInputFrame.new(self)
    self.outputSettingsFrame = MachineSettingsOutputFrame.new(self)
    self.landscapingSettingsFrame = MachineSettingsLandscapingFrame.new(self)
    self.areaSettingsFrame = MachineSettingsAreaFrame.new(self)

    g_gui:loadGui(MachineSettingsFrame.XML_FILENAME, MachineSettingsFrame.CLASS_NAME, self.settingsFrame, true)
    g_gui:loadGui(MachineSettingsInputFrame.XML_FILENAME, MachineSettingsInputFrame.CLASS_NAME, self.inputSettingsFrame, true)
    g_gui:loadGui(MachineSettingsOutputFrame.XML_FILENAME, MachineSettingsOutputFrame.CLASS_NAME, self.outputSettingsFrame, true)
    g_gui:loadGui(MachineSettingsLandscapingFrame.XML_FILENAME, MachineSettingsLandscapingFrame.CLASS_NAME, self.landscapingSettingsFrame, true)
    g_gui:loadGui(MachineSettingsAreaFrame.XML_FILENAME, MachineSettingsAreaFrame.CLASS_NAME, self.areaSettingsFrame, true)

    g_gui:loadGui(MachineScreen.XML_FILENAME, MachineScreen.CLASS_NAME, self)
end

function MachineScreen:onGuiSetupFinished()
    self:superClass().onGuiSetupFinished(self)

    self.settingsFrame:initialize()
    self.inputSettingsFrame:initialize()
    self.outputSettingsFrame:initialize()
    self.landscapingSettingsFrame:initialize()
    self.areaSettingsFrame:initialize()

    self:setupPages()
end

function MachineScreen:setupPages()
    ---@return boolean
    local function calibrationPredicateFn()
        if self.vehicle ~= nil then
            return MachineUtils.getHasInputMode(self.vehicle, Machine.MODE.LOWER)
                or MachineUtils.getHasInputMode(self.vehicle, Machine.MODE.FLATTEN)
                or MachineUtils.getHasOutputMode(self.vehicle, Machine.MODE.RAISE)
                or MachineUtils.getHasOutputMode(self.vehicle, Machine.MODE.FLATTEN)
        end

        return false
    end

    local pages = {
        {
            self.settingsFrame,
            'terraFarm.icon_excavator'
        },
        {
            self.inputSettingsFrame,
            'terraFarm.icon_input'
        },
        {
            self.outputSettingsFrame,
            'terraFarm.icon_output'
        },
        {
            self.landscapingSettingsFrame,
            'gui.icon_construction_terraforming'
        },
        {
            self.areaSettingsFrame,
            'terraFarm.icon_area',
            calibrationPredicateFn
        },
    }

    for i, page in ipairs(pages) do
        local element, iconSliceId, enablingPredicateFunction = unpack(page)

        self:registerPage(element, i, enablingPredicateFunction)
        self:addPageTab(element, nil, nil, iconSliceId)
    end
end

function MachineScreen:setupMenuButtonInfo()
    local onButtonBackFunction = self.clickBackCallback
    local onButtonSettingsFunction = self:makeSelfCallback(self.onClickGlobalSettings)

    self.backButtonInfo = {
        inputAction = InputAction.MENU_BACK,
        text = g_i18n:getText(InGameMenu.L10N_SYMBOL.BUTTON_BACK),
        callback = onButtonBackFunction
    }

    self.settingsButtonInfo = {
        inputAction = InputAction.MENU_EXTRA_2,
        text = g_i18n:getText('ui_globalSettings'),
        callback = onButtonSettingsFunction
    }

    self.defaultMenuButtonInfo = {
        self.backButtonInfo,
        self.settingsButtonInfo
    }
    self.defaultMenuButtonInfoByActions[InputAction.MENU_BACK] = self.backButtonInfo
    self.defaultMenuButtonInfoByActions[InputAction.MENU_EXTRA_2] = self.settingsButtonInfo

    self.defaultButtonActionCallbacks = {
        [InputAction.MENU_BACK] = onButtonBackFunction,
        [InputAction.MENU_EXTRA_2] = onButtonSettingsFunction
    }
end

---@param vehicle Machine?
function MachineScreen:show(vehicle)
    if vehicle ~= nil then
        self.vehicle = vehicle
        self.screenBgElement:setVisible(g_gui.currentGui ~= nil)
        g_gui:showDialog(MachineScreen.CLASS_NAME)
    end
end

---@param visible boolean
function MachineScreen:setShowOverlay(visible)
    self.showOverlay = visible
end

function MachineScreen:exitMenu()
    self:popToRoot()
    g_gui:closeDialogByName(self.name)
end

function MachineScreen:onOpen()
    ScreenElement.onOpen(self)

    ---@diagnostic disable-next-line: undefined-global
    self:playSample(GuiSoundPlayer.SOUND_SAMPLES.PAGING)
    self:setSoundSuppressed(true)

    local top = self:getTopFrame()

    if self:isAtRoot() then
        self:updatePages()
        ---@diagnostic disable-next-line: undefined-field
        self.pageSelector:setState(self.restorePageIndex, true)
    else
        top:onFrameOpen()
        self:updateButtonsPanel(top)
    end

    self:setSoundSuppressed(false)
    self:onMenuOpened()
    self:updateVehicle()

    g_messageCenter:subscribe(ModMessageType.MACHINE_REMOVE, self.onMachineRemove, self)

    FocusManager:lockFocusInput(InputAction.MENU_PAGE_NEXT, 150)
    FocusManager:lockFocusInput(InputAction.MENU_PAGE_PREV, 150)
    FocusManager:lockFocusInput(FocusManager.TOP, 150)
    FocusManager:lockFocusInput(FocusManager.BOTTOM, 150)
end

function MachineScreen:onClose()
    if self.currentPage ~= nil then
        self.currentPage:onFrameClose()
    end

    ScreenElement.onClose(self)

    g_inputBinding:storeEventBindings()
    self:clearMenuButtonActions()

    ---@diagnostic disable-next-line: undefined-field
    self.restorePageIndex = self.pageSelector:getState()
    ---@diagnostic disable-next-line: undefined-field
    self.restorePageScrollOffset = self.pagingTabList.viewOffset

    self.vehicle = nil

    g_messageCenter:unsubscribeAll(self)
end

function MachineScreen:onClickBack()
    if self.currentPage:requestClose(self.clickBackCallback) then
        self:exitMenu()
        return false
    end

    return true
end

---@param vehicle Machine
function MachineScreen:onMachineRemove(vehicle)
    if vehicle ~= nil and vehicle == self.vehicle then
        self:exitMenu()
    end
end

-- TODO
function MachineScreen:updateVehicle()
    -- if self.vehicle ~= nil then
    --     local spec = self.vehicle.spec_machine

    --     self.vehicleImage:setImageFilename(self.vehicle:getImageFilename())
    --     self.machineTypeName:setText(spec.machineType.name)
    --     self.vehicleName:setText(self.vehicle:getName())

    --     if self.vehicle.brand ~= nil then
    --         self.vehicleBrandName:setText(self.vehicle.brand.title)
    --     else
    --         self.vehicleBrandName:setText('Unknown')
    --     end
    -- end
end

---@param dt number
function MachineScreen:update(dt)
    ScreenElement.update(self, dt)

    if FocusManager.currentGui ~= self.currentPageName and #g_gui.dialogs == 1 then
        FocusManager:setGui(self.currentPageName)
    end

    if self.currentPage ~= nil then
        if self.currentPage:isMenuButtonInfoDirty() then
            self:assignMenuButtonInfo(self.currentPage:getMenuButtonInfo())
            self.currentPage:clearMenuButtonInfoDirty()
        end

        if self.currentPage:isTabbingMenuVisibleDirty() then
            self:updatePagingVisibility(self.currentPage:getTabbingMenuVisible())
        end
    end
end

function MachineScreen:onClickGlobalSettings()
    local function callback()
        self:setShowOverlay(false)
    end

    self:setShowOverlay(true)

    g_globalSettingsDialog:setCloseCallback(callback)
    g_globalSettingsDialog:show()
end

function MachineScreen:getStack(page)
    local pageId = self.currentPageId
    if page ~= nil then
        ---@diagnostic disable-next-line: undefined-field
        pageId = self.pagingElement:getPageIndexByElement(page)
    else
        ---@diagnostic disable-next-line: undefined-field
        page = self.pagingElement:getPageElementByIndex(pageId)
    end

    if self.stacks[pageId] == nil then
        self.stacks[pageId] = {}

        local root = {
            page = page,
            pageId = pageId,
            isRoot = true,
        }

        table.insert(self.stacks[pageId], root)
    end

    return self.stacks[pageId]
end

---@param self TabbedMenuWithDetails
---@diagnostic disable-next-line: lowercase-global
function MachineScreen:reset()
    TabbedMenu.reset(self)

    self.currentPageName = ''
    self.stacks = {}
end

function MachineScreen:onPageChange(pageIndex, pageMappingIndex, element, skipTabVisualUpdate)
    -- If the new page is a detail page, then do not update
    if self.isChangingDetail then
        skipTabVisualUpdate = true
    else
        self:popToRoot()
    end

    if self.currentPage ~= nil then
        self.currentPage:onFrameClose()
        self.currentPage:setVisible(false)
    end

    g_inputBinding:storeEventBindings() -- reset any disabled bindings for page custom input in menu context

    ---@diagnostic disable-next-line: undefined-field
    local page = self.pagingElement:getPageElementByIndex(pageIndex)
    self.currentPage = page
    self.currentPageName = page.name -- store page name for FocusManager GUI context override in update()
    self.currentPageListIndex = pageMappingIndex

    if not skipTabVisualUpdate then
        self.currentPageId = pageIndex
        ---@diagnostic disable-next-line: undefined-field
        self.pagingTabList:setSelectedIndex(pageMappingIndex)
    end

    page:setVisible(true)
    page:setSoundSuppressed(true)
    FocusManager:setGui(page.name)
    page:setSoundSuppressed(false)

    self:updateButtonsPanel(page)
    self:updateTabDisplay()

    page:onFrameOpen()
end

function MachineScreen:draw(...)
    MachineScreen:superClass().draw(self, ...)

    if self.showOverlay then
        self.overlayElement:draw(...)
    end
end
